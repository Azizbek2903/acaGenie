# AcaGenie — One-pager (AI500)

**Tashabbus:** AcaGenie — ta'limda individual yondashuvni kengaytiruvchi AI yordamchisi.

**Muammo:** Maktab va onlayn kurslarda ko'plab talabalar umumiy metodlardan charchaydi. O'qituvchilar har bir talabaga vaqt ajrata olmaydi.

**Yeсhim:** AcaGenie diagnostika testlari bilan boshlaydi, embeddings orqali talaba profilini saqlaydi va LLM yordamida personalizatsiya qilingan mashqlar va step-by-step izohlar beradi.

**KPI:** learning gain ≥30%, retention ≥40%, teacher time saved (soat/hafta).

**Tex Stack:** Next.js, Node.js serverless api, OpenAI (GPT-5), Pinecone, Supabase.

**Demo:** Live chat va diagnostic demo orqali hakamlarga real tajriba ko'rsatiladi.

