# AcaGenie — AI500 Demo

Professional demo for AI500 1-bosqich.

## Contents
- index.html (frontend)
- style.css
- script.js
- api/chat.js (serverless endpoint for OpenAI)

## How it works
- Frontend: static single-page site with a chat UI.
- Backend: serverless `/api/chat` proxies prompts to OpenAI Chat Completion API.
- Deploy recommended: Vercel (easy serverless + env vars).

## Deploy on Vercel (recommended)
1. Create a GitHub repo (e.g. `acagenie-demo`) and push all files preserving directory structure (`api/chat.js` must be inside `api/` folder).
2. Go to https://vercel.com and connect your GitHub account.
3. Import the repo as a new project and Deploy.
4. In Vercel Project Settings → Environment Variables add:
   - `OPENAI_API_KEY` = your OpenAI secret key (sk-...)
5. Redeploy. Your site will be available at `https://<your-project>.vercel.app` and the chat endpoint will be `/api/chat`.

## Deploy on Netlify (alternative)
Netlify supports serverless functions but configuration differs. If you prefer Netlify, upload static files and add a lambda function (Netlify Functions) for `/api/chat`.

## Important
- Do NOT put the OpenAI API key in client-side code.
- For competition submission provide the live URL (Vercel/Netlify) and GitHub repo link.
- If you want, I can prepare a one-page pitch PDF and a short video script for the demo.

## Pitch (copy for AI500 submission)
**Loyiha:** AcaGenie — AI shaxsiy ta'lim yordamchisi  
**Muammo:** Individual o'qitish resurs talab qiladi va ko'p o'quvchilar darsni tushunmaydi.  
**Yechim:** AI diagnostika, adaptiv mashqlar, instant explainers va progress dashboard.  
**MVP:** Diagnostic test, adaptive quiz, AI chat, dashboard.  
**Live demo:** (give your Vercel link)  
**Repo:** https://github.com/YOUR_USERNAME/YOUR_REPO

Good luck — agar xohlasangiz men bu repo’ni GitHub-ready ZIP yoki push commands bilan tayyorlab beraman.
