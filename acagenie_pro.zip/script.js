const messagesEl = document.getElementById('messages');
const form = document.getElementById('chatForm');
const input = document.getElementById('prompt');
const statusEl = document.getElementById('status');

function append(role, text){
  const d = document.createElement('div');
  d.className = role === 'user' ? 'user' : 'bot';
  d.textContent = text;
  messagesEl.appendChild(d);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function sendPrompt(prompt){
  append('user', prompt);
  input.value = '';
  append('bot', '🤖 Javob tayyorlanmoqda...');
  try {
    const resp = await fetch('/api/chat', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({prompt})
    });
    const data = await resp.json();
    const bots = messagesEl.querySelectorAll('.bot');
    const last = bots[bots.length-1];
    if(last && last.textContent === '🤖 Javob tayyorlanmoqda...') last.remove();
    if(data && data.text) append('bot', data.text);
    else append('bot','Serverdan javob kelmadi.');
  } catch(e){
    const bots = messagesEl.querySelectorAll('.bot');
    const last = bots[bots.length-1];
    if(last && last.textContent === '🤖 Javob tayyorlanmoqda...') last.remove();
    append('bot','Xatolik: ' + e.message);
  }
}

form.addEventListener('submit', (e)=>{
  e.preventDefault();
  const v = input.value.trim();
  if(!v) return;
  sendPrompt(v);
});
